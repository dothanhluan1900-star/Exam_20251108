import math

x1 = int(input("Nhập X1: "))
x2 = int(input("Nhập X2: "))
x3 = int(input("Nhập X3: "))

min_num = min(x1, x2, x3)
print("Số nhỏ nhất là:", min_num)
