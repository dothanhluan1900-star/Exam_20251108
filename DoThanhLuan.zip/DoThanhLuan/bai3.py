
t = float(input("Nhập nhiệt độ hiện tại: "))

if t > 30:
    print("thoi tiet nongggggg")
elif t < 20:
    print("thoi tiet lanhhhhh")
else:
    print("thoi tiet de chiuuuu")
