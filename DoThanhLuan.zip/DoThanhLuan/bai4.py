
mk1 = input("nhap mk moi: ")
mk2 = input("xac nhan mk moi: ")

if mk1 == mk2:
    print("mk da doi thanh cong")
else:
    print("mk ko giong nhau")