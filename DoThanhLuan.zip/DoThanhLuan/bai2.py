
n = int(input("Nhap nam N: "))

if (n % 4 == 0 and n % 100 != 0) or (n % 400 == 0):
    print("nam", n, "la nam nhuan.")
else:
    print("Nam", n, "ko phai nam nhuan.")
